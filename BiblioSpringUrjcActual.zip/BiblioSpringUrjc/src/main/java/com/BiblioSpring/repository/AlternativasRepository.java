package com.BiblioSpring.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.BiblioSpring.entity.Alternativa;

public interface AlternativasRepository extends JpaRepository<Alternativa, Long> {

}
