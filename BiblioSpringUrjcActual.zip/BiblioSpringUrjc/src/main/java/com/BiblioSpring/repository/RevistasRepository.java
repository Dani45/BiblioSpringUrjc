package com.BiblioSpring.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.BiblioSpring.entity.Revista;

public interface RevistasRepository extends JpaRepository<Revista,Long>{

}
